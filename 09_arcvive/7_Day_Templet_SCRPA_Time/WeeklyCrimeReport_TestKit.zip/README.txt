# Weekly Crime Report - Test Kit

This kit helps you test the Updated Weekly Crime Report tool inside ArcGIS Pro.

## Included Files

- `SCRPA_Exports.tbx` – Your toolbox (manually add this in ArcGIS Pro)
- `Updated_Weekly_Crime_Report.py` – Script file for your tool
- `chart_suffixes.csv` – Suffix config
- `email_recipients.csv` – Email config
- `README.txt` – This guide

## How to Test (Step-by-Step)

1. Open ArcGIS Pro
2. Add toolbox:
   - In Catalog > Toolboxes, right-click > Add Toolbox
   - Browse to `SCRPA_Exports.tbx`
3. Right-click `Updated Weekly Crime Report` > Properties
   - Go to Parameters tab
   - Enter the 6 parameters listed earlier (Report, Email, etc.)
   - Set the same order as shown in instructions
4. Save and close properties
5. Double-click the tool
6. Set:
   - ✅ Report Only = true
   - ✅ Dry Run Mode = true
   - Leave the rest as default
7. Click **Run**

## Expected Output

- A PDF called `DRY_RUN_Summary.pdf` will be generated in:
  `C:\Users\carucci_r\OneDrive - City of Hackensack\_25_SCRPA\TIME_Based\Reports`

Use this dry-run to confirm everything is wired correctly before sending real data or emails.